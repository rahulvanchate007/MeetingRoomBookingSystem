package meetingroombooking;  
  
public interface Provider {  
String DRIVER="com.mysql.cj.jdbc.Driver";  
String CONNECTION_URL="jdbc:mysql://localhost:3306/root";  
String USERNAME="root";  
String PASSWORD="root";  
  
}  