package Bean;  
  
public class LoginBean {  
private String uname,pwd;  
  
public String getuname() {  
    return uname;  
}  
  
public void setuname(String uname) {  
    this.uname = uname;  
}  
  
public String getpwd() {  
    return pwd;  
}  
  
public void setpwd(String pwd) {  
    this.pwd = pwd;  
}  
  
  
}  
